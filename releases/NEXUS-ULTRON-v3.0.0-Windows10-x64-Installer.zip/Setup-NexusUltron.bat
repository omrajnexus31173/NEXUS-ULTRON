@echo off
call "%~dp0installer\windows\Install-NexusUltron.bat" %*
